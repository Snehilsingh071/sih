# Standard Django settings with REST Framework & PostgreSQL
INSTALLED_APPS = [
    ...
    'rest_framework',
    'django.contrib.postgres',
    'chatbot',
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'farmdb',
        'USER': 'farmuser',
        'PASSWORD': 'password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
LANGUAGES = [
    ('en', 'English'),
    ('hi', 'Hindi'),
    # add more local languages
]