from rest_framework import routers
from .views import FarmerViewSet, CropHistoryViewSet, SoilSampleViewSet, CropImageViewSet

router = routers.DefaultRouter()
router.register(r'farmers', FarmerViewSet)
router.register(r'crophistory', CropHistoryViewSet)
router.register(r'soilsample', SoilSampleViewSet)
router.register(r'cropimage', CropImageViewSet)

urlpatterns = router.urls