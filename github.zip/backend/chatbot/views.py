from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Farmer, CropHistory, SoilSample, CropImage
from .serializers import FarmerSerializer, CropHistorySerializer, SoilSampleSerializer, CropImageSerializer

class FarmerViewSet(viewsets.ModelViewSet):
    queryset = Farmer.objects.all()
    serializer_class = FarmerSerializer

class CropHistoryViewSet(viewsets.ModelViewSet):
    queryset = CropHistory.objects.all()
    serializer_class = CropHistorySerializer

class SoilSampleViewSet(viewsets.ModelViewSet):
    queryset = SoilSample.objects.all()
    serializer_class = SoilSampleSerializer

class CropImageViewSet(viewsets.ModelViewSet):
    queryset = CropImage.objects.all()
    serializer_class = CropImageSerializer

    @action(detail=True, methods=['post'])
    def analyze(self, request, pk=None):
        # Here is where ML model is called for disease detection
        crop_image = self.get_object()
        # result = call_resnet_model(crop_image.image.path)
        result = {"disease": "blight", "health": "poor"} # Example
        crop_image.detected_disease = result['disease']
        crop_image.health_status = result['health']
        crop_image.save()
        return Response(result)