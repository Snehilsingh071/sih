from .ml_services import recommend_crop, recommend_fertilizer
from .external_api import get_weather, get_market_price

def generate_advisory(farmer, soil_sample, crop_history):
    weather = get_weather(farmer.location)
    best_crop = recommend_crop(soil_sample.soil_type, weather, crop_history)
    fertilizer = recommend_fertilizer(soil_sample, best_crop)
    market_price = get_market_price(best_crop, farmer.location)
    return {
        "best_crop": best_crop,
        "fertilizer": fertilizer,
        "market_price": market_price,
        "weather": weather,
    }