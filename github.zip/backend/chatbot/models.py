from django.db import models

class Farmer(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    location = models.CharField(max_length=255)
    language = models.CharField(max_length=10, default='en')

class CropHistory(models.Model):
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE)
    crop = models.CharField(max_length=50)
    season = models.CharField(max_length=20)
    year = models.IntegerField()
    yield_amount = models.FloatField(null=True, blank=True)

class SoilSample(models.Model):
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE)
    soil_type = models.CharField(max_length=50)
    ph = models.FloatField()
    npk_ratio = models.CharField(max_length=20)
    collected_date = models.DateField(auto_now_add=True)

class CropImage(models.Model):
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='crop_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    detected_disease = models.CharField(max_length=100, null=True, blank=True)
    health_status = models.CharField(max_length=100, null=True, blank=True)