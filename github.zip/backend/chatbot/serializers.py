from rest_framework import serializers
from .models import Farmer, CropHistory, SoilSample, CropImage

class FarmerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Farmer
        fields = '__all__'

class CropHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CropHistory
        fields = '__all__'

class SoilSampleSerializer(serializers.ModelSerializer):
    class Meta:
        model = SoilSample
        fields = '__all__'

class CropImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = CropImage
        fields = '__all__'