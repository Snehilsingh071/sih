import requests

def get_weather(location):
    # Call external weather API
    # return weather data
    pass

def get_market_price(crop, location):
    # Call external or government agri price API
    pass

def translate(text, target_lang):
    # Use Google Translate API
    pass